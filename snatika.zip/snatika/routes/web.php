<?php

use Illuminate\Support\Facades\Route; 
  
use App\Http\Controllers\Auth\AuthController;
use App\Http\Controllers\MCQController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('index');
});

Route::get('/home', function () {
    return view('home');
});

Route::get('disclaimer', [AuthController::class, 'disclaimer'])->name('disclaimer');
Route::get('interest', [AuthController::class, 'interest'])->name('interest');
Route::get('gohome', [AuthController::class, 'gohome'])->name('gohome');
Route::get('assessment', [AuthController::class, 'assessment'])->name('assessment');

Route::get('login', [AuthController::class, 'index'])->name('login');
Route::post('post-login', [AuthController::class, 'postLogin'])->name('login.post'); 
Route::get('registration', [AuthController::class, 'registration'])->name('register');
Route::post('post-registration', [AuthController::class, 'postRegistration'])->name('register.post'); 
Route::get('dashboard', [AuthController::class, 'dashboard']); 
Route::get('logout', [AuthController::class, 'logout'])->name('logout');

Route::post('user-submit', [AuthController::class, 'postUser'])->name('user.post'); 

Route::get('question', [MCQController::class, 'question'])->name('question'); 
Route::post('post-question', [MCQController::class, 'postQuestion'])->name('question.post'); 
Route::post('post-test', [MCQController::class, 'postUserTest'])->name('user.testsave'); 
Route::get('congratulation', [MCQController::class, 'congratulation'])->name('congratulation'); 