
  
<?php $__env->startSection('content'); ?>
<main class="login-form">
  <div class="cotainer">
      <div class="row justify-content-center">
          <div class="col-md-8">
              <div class="card">
                  <div class="card-header">Question Bank</div>
                  <div class="card-body">
                      <?php if(session('success')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('success')); ?>

                        </div>
                      <?php endif; ?>
                      <form action="<?php echo e(route('question.post')); ?>" method="POST">
                          <?php echo csrf_field(); ?>
                          <div class="form-group row"> 
                              <label for="name" class="col-md-4 col-form-label text-md-right">Question <span class="req">*</span></label>
                              <div class="col-md-6">
                                  <textarea type="text" id="question" class="form-control" name="question"  autofocus><?php echo e(old('question')); ?></textarea>
                                  <?php if($errors->has('question')): ?>
                                      <span class="text-danger"><?php echo e($errors->first('question')); ?></span>
                                  <?php endif; ?>
                              </div>
                          </div>
  
                          <div class="form-group row">
                              <label for="email_address" class="col-md-4 col-form-label text-md-right">Option A <span class="req">*</span></label>
                              <div class="col-md-6">
                                  <input type="text" id="option_a" value="<?php echo e(old('option_a')); ?>" class="form-control" name="option_a">
                                  <?php if($errors->has('option_a')): ?>
                                      <span class="text-danger"><?php echo e($errors->first('option_a')); ?></span>
                                  <?php endif; ?>
                              </div>
                          </div>
                          
                          <div class="form-group row">
                              <label for="email_address" class="col-md-4 col-form-label text-md-right">Option B <span class="req">*</span></label>
                              <div class="col-md-6">
                                  <input type="text" id="option_b"  value="<?php echo e(old('option_b')); ?>" class="form-control" name="option_b">
                                  <?php if($errors->has('option_b')): ?>
                                      <span class="text-danger"><?php echo e($errors->first('option_b')); ?></span>
                                  <?php endif; ?>
                              </div>
                          </div>

                          <div class="form-group row">
                              <label for="email_address" class="col-md-4 col-form-label text-md-right">Option C <span class="req">*</span></label>
                              <div class="col-md-6">
                                  <input type="text" id="option_c" value="<?php echo e(old('option_c')); ?>"  class="form-control" name="option_c">
                                  <?php if($errors->has('option_c')): ?>
                                      <span class="text-danger"><?php echo e($errors->first('option_c')); ?></span>
                                  <?php endif; ?>
                              </div>
                          </div>
                          <div class="form-group row">
                              <label for="email_address" class="col-md-4 col-form-label text-md-right">Option D <span class="req">*</span></label>
                              <div class="col-md-6">
                                  <input type="text" id="option_d"  value="<?php echo e(old('option_d')); ?>" class="form-control" name="option_d" >
                                  <?php if($errors->has('option_d')): ?>
                                      <span class="text-danger"><?php echo e($errors->first('option_d')); ?></span>
                                  <?php endif; ?>
                              </div>
                          </div>

                          <div class="form-group row">
                              <label for="email_address" class="col-md-4 col-form-label text-md-right">Answer <span class="req">*</span></label>
                              <div class="col-md-6">
                                  <select id="answer"  value="<?php echo e(old('answer')); ?>" class="form-control" name="answer">
                                    <option value="">Select Answer</option>
                                    <option>A</option>
                                    <option>B</option>
                                    <option>C</option>
                                    <option>D</option>
                                  </select>
                                  <?php if($errors->has('answer')): ?>
                                      <span class="text-danger"><?php echo e($errors->first('answer')); ?></span>
                                  <?php endif; ?>
                              </div>
                          </div>
                          
                          <div class="col-md-6 offset-md-4">
                              <button type="submit" class="btn btn-primary">
                                  Save
                              </button>
                          </div>
                      </form>
                      <div class="clearfix"></div>
                      <br>
                      <div class="table-responsive">
                        <table class="table table-bordered table-stripped table-hover">
                          <thead>
                            <tr>
                              <th>SNo.</th>
                              <th>Question</th>
                              <th>Option A</th>
                              <th>Option B</th>
                              <th>Option C</th>
                              <th>Option D</th>
                              <th>Answer</th>
                            </tr>
                          </thead>
                          <tbody>
                            <?php if(empty($data)): ?>
                            <tr>
                              <th>Record Not found.</th>
                              <th></th>
                              <th></th>
                              <th></th>
                              <th></th>
                              <th></th>
                              <th></th>
                            </tr>
                            <?php else: ?>
                              <?php
                                $count=1;
                              ?>
                              <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                  <td><?php echo e($count++); ?></td>
                                  <td><?php echo e($row->question); ?></td>
                                  <td><?php echo e($row->option_a); ?></td>
                                  <td><?php echo e($row->option_b); ?></td>
                                  <td><?php echo e($row->option_c); ?></td>
                                  <td><?php echo e($row->option_d); ?></td>
                                  <td><?php echo e($row->answer); ?></td>
                                </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                          </tbody>
                        </table>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp81\htdocs\snatika\resources\views/question.blade.php ENDPATH**/ ?>