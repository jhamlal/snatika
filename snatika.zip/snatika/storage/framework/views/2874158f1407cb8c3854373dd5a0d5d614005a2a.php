<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Snatika - Assignment</title>
	
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>

	<style type="text/css">
		body {
			margin: 1%;
			border: 2px solid #c211a7;
			background-color:  #f2f2f2;
		}
		.section {
			padding:20px 0 60px 0; 
		}
		.main-head h2{ 
			color:  #990099;
			text-align: center;
			margin-top: 3%;
		}
		.detail-sec{
			border-top: 12px solid #990099;
			background-color: #ffffff; 
			padding: 5px;
		}
		.detail-sec h4{
			text-align: left; 
			margin: 3% 0 0 3%;
		}
		.detail-sec h5{
			text-align: center;
			margin-top: 20px;
		}

		.detail-sec p {
			text-align : justify;
			margin: 25px 10px 5px 10px;
		}
		.btn-sec{
			margin: 4em 0 2em 0;
			text-align: center;
		}
		.custom-btn{
			background-color: #990099; 
			border: none;
			color : #ffffff;
			font-weight: bold;
			padding: 7px 25px;
		}
		.custom-btn:hover{
			background-color: #000; 
			border: none;
			color : #ffffff;
			font-weight: bold;
			padding: 7px 25px;
		}	
		.snatika{
			color : #990099;
		}
		.custom-btnexit{
			background-color: #000; 
			border: none;
			color : #ffffff;
			font-weight: bold;
			padding: 7px 25px;
		}
		.custom-btnexit:hover{
			background-color: #990099; 
			border: none;
			color : #ffffff;
			font-weight: bold;
			padding: 7px 25px;
		}	

		.form-check
		{
			margin-top: 1%;
			margin-left: 4%;
		}


		.question {
		    display: none;
		}

		#q-1{
			display: block;
		}
				 
	</style>
</head>
<body>
	<div class="container">
		<div class="section">
			<div class="row">
				<div class="col main-head">
					<h2>Program Eligibility Test </h2>
				</div>
			</div>

			<div class="row">
				<div class="col-1 col-md-1"></div>
				<div class="col-10 col-md-10 detail-sec">
				<form method="POST" action="<?php echo e(route('user.testsave')); ?>">
					<?php echo csrf_field(); ?>
					<?php
						$counter=1;
						$total_ques = count($question_list);
					?>
					<?php $__currentLoopData = $question_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="question" id="q-<?php echo e($counter); ?>">
						<h4><?php echo e($counter); ?> . <?=$row->question?>  </h4>
						<input type="hidden" name="question_id[]" value="<?php echo e($row->id); ?>">
						<div class="form-check">
						  	<input class="form-check-input" type="radio" name="answer<?php echo e($row->id); ?>" id="answer<?php echo e($row->id); ?>a" value="A">
						  	<label class="form-check-label" for="answer<?php echo e($row->id); ?>a">
						    	<?php echo e($row->option_a); ?>

						  	</label>
						</div>

						<div class="form-check">
						  	<input class="form-check-input" type="radio" name="answer<?php echo e($row->id); ?>" id="answer<?php echo e($row->id); ?>b" value="B">
						  	<label class="form-check-label" for="answer<?php echo e($row->id); ?>b">
						    	<?php echo e($row->option_b); ?>

						  	</label>
						</div>

						<div class="form-check">
						  	<input class="form-check-input" type="radio" name="answer<?php echo e($row->id); ?>" id="answer<?php echo e($row->id); ?>c" value="C">
						  	<label class="form-check-label" for="answer<?php echo e($row->id); ?>c">
						    	<?php echo e($row->option_c); ?>

						  	</label>
						</div>

						<div class="form-check">
						  	<input class="form-check-input" type="radio" name="answer<?php echo e($row->id); ?>" id="answer<?php echo e($row->id); ?>d" value="D">
						  	<label class="form-check-label" for="answer<?php echo e($row->id); ?>d">
						    	<?php echo e($row->option_d); ?>

						  	</label>
						</div>

						<div class="clearfix"></div>
						<div class="row btn-sec">
							<div class="col-4 col-md-4"><a type="button" class="custom-btnexit" href="<?php echo e(route('gohome')); ?>" style="text-decoration: none;">Exit</a></div>
							<?php if($counter!=1): ?>
							<div class="col-4 col-md-4"><button type="button" class="custom-btn prev"   style="text-decoration: none;">Previous Question </button></div>
							<?php endif; ?>

							<?php if($counter!=$total_ques): ?>
							<div class="col-4 col-md-4"><button type="button" class="custom-btn next"   style="text-decoration: none;">Next Question</button></div>
							<?php endif; ?>

							<?php if($counter==$total_ques): ?>
							<div class="col-4 col-md-4"><button type="submit" class="custom-btn"   style="text-decoration: none;">Final Submit</button></div>
							<?php endif; ?>
						</div>
					</div>
					<?php
						 $counter++;
					?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</form>
				</div>
				<div class="col-1 col-md-1"></div>
			</div>
		</div>
	</div>
</body>
</html>

 <script>
 		var activeIndex = 1;
       	$(".next").click(function(){
		   $("#q-"+activeIndex).hide();
		   activeIndex++;
		   $("#q-"+activeIndex).show();  
		});

		$(".prev").click(function(){
		   $("#q-"+activeIndex).hide();
		   activeIndex--;
		   $("#q-"+activeIndex).show();  
		}); 

    </script><?php /**PATH D:\xampp81\htdocs\snatika\resources\views/assessment.blade.php ENDPATH**/ ?>