<?php
  
namespace App\Http\Controllers\Auth;
  
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Session;
use App\Models\User;
use Hash,DB;
  
class AuthController extends Controller
{
    /**
     * Write code on Method
     *
     * @return response()
     */
    public function index()
    {
        return view('auth.login');
    }  
      
    /**
     * Write code on Method
     *
     * @return response()
     */
    public function registration()
    {
        return view('auth.registration');
    }
      
    /**
     * Write code on Method
     *
     * @return response()
     */
    public function postLogin(Request $request)
    {
        $request->validate([
            'email' => 'required',
            'password' => 'required',
        ]);
   
        $credentials = $request->only('email', 'password');
        if (Auth::attempt($credentials)) {
            return redirect()->intended('dashboard')
                        ->withSuccess('You have Successfully loggedin');
        }
  
        return redirect("login")->withSuccess('Oppes! You have entered invalid credentials');
    }
      
    /**
     * Write code on Method
     *
     * @return response()
     */
    public function postRegistration(Request $request)
    {  
        $request->validate([
            'name' => 'required',
            'email' => 'required|email|unique:users',
            'password' => 'required|min:6',
        ]);
           
        $data = $request->all();
        $check = $this->create($data);
         
        return redirect("dashboard")->withSuccess('Great! You have Successfully loggedin');
    }
    
    /**
     * Write code on Method
     *
     * @return response()
     */

    public function home()
    {
        return redirect("home")->withSuccess('Welcome to SNATIKA');
    }

    public function dashboard()
    {
        if(Auth::check()){
            return view('dashboard');
        }
  
        return redirect("login")->withSuccess('Opps! You do not have access');
    }
    
    /**
     * Write code on Method
     *
     * @return response()
     */
    public function create(array $data)
    {
      return User::create([
        'name' => $data['name'],
        'email' => $data['email'],
        'password' => Hash::make($data['password'])
      ]);
    }

    public function createUser(array $data)
    {
      return User::create([
        'name' => $data['name'],
        'email' => $data['email'],
        'type' => $data['type'],
        'phone' => $data['phone'],
        'contry_code' => $data['contry_code'],
        'password' => Hash::make($data['password'])
      ]);
    }
    
    /**
     * Write code on Method
     *
     * @return response()
     */
    public function logout() {
        Session::flush();
        Auth::logout();
  
        return Redirect('login');
    }

    public function postUser(Request $request)
    {   
        //dd($request->all());
        $request->validate([
            'phone' => 'required',
            'name' => 'required',
            'email' => 'required|email|unique:users', 
        ]);
           
        $data = $request->all();
        // $data['phone'] = $request->phone;
        // $data['name'] = $request->name;
        // $data['email'] = $request->email; 
        $data['password'] = $request->phone; 
        $data['type'] = 'user';
        $check = $this->createUser($data);

        $credentials = array('email'=>$request->email,'password'=>$request->phone);
        if (Auth::attempt($credentials)) {
            return redirect("home")->withSuccess('Great! You have Successfully loggedin');
        }
         
        return redirect("home")->withSuccess('Great! You have Successfully loggedin');
    }

    public function disclaimer()
    {
        return view('disclaimer');
    } 

    public function interest()
    {
        return view('interest');
    } 

    public function gohome()
    {
        return view('home');
    } 

    public function assessment()
    {
        $question_list = DB::table('questions')->orderby('id', 'asc')->get();
        return view('assessment',compact('question_list'));
    } 

}