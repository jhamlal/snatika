<?php
  
namespace App\Http\Controllers;
  
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Session;
use App\Models\User;
use Hash,DB;
  
class MCQController extends Controller
{
    /**
     * Write code on Method
     *
     * @return response()
     */
    public function question()
    {
        $data = DB::table('questions')->orderby('question')->get();
        return view('question',compact('data'));
    }  
       
   
    public function postQuestion(Request $request)
    {  
        $request->validate([            
            'question' => 'required|unique:questions',
            'option_a' => 'required',
            'option_b' => 'required',
            'option_c' => 'required',
            'option_d' => 'required',
            'answer' => 'required',
        ]);
           
        $data['question'] = $request->question;
        $data['option_a'] = $request->option_a;
        $data['option_b'] = $request->option_b;
        $data['option_c'] = $request->option_c;
        $data['option_d'] = $request->option_d;
        $data['answer'] = $request->answer; 
        $data['created_at'] = date('Y-m-d H:i:s');
        $data['created_by'] = Auth::user()->name;
        $check = DB::table('questions')->insert($data);
         
        return redirect("question")->withSuccess('Data Saved Successfully..');
    }   

    public function postUserTest(Request $request)
    {       
        $test_no = Auth::user()->id.date('ymdhis');
        $question_id=$request->question_id;
        
        $zipped = array_map(null,$question_id);
        foreach($request->question_id as $key=>$que_id)
        {           
            $answer1=$request->{'answer'.($que_id)};
            $data['question_id'] = $que_id;
            $data['answer']  = $answer1;
            $data['test_no'] = $test_no; 
            $data['created_at'] = date('Y-m-d H:i:s');
            $data['user_id'] = Auth::user()->id;
            DB::table('test')->insert($data);
        }   
         
        return redirect("congratulation")->withSuccess('Data Saved Successfully..');
    }   
    

    public function congratulation()
    {
        return view('congratulation');
    } 
}