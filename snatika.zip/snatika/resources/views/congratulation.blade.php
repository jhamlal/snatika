<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Snatika - Assignment</title>
	
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
	<style type="text/css">
		body {
			margin: 1%;
			border: 2px solid #c211a7;
			background-color:  #f2f2f2;
		}
		.section {
			padding:20px 0 60px 0; 
		}
		.main-head h2{ 
			color:  #990099;
			text-align: center;
			margin-top: 3%;
		}
		.detail-sec{
			border-top: 12px solid #990099;
			background-color: #ffffff; 
			padding: 5px;
		}
		.detail-sec h3{
			text-align: center;
			margin-top: 5px;
		}
		.detail-sec h5{
			text-align: center;
			margin-top: 20px;
		}
		.detail-sec p {
			text-align : justify;
			margin: 25px 10px 5px 10px;
		}
		.btn-sec{
			margin: 4em 0 2em 0;
			text-align: center;
		}
		.custom-btn{
			background-color: #990099; 
			border: none;
			color : #ffffff;
			font-weight: bold;
			padding: 7px 25px;
		}
		.custom-btn:hover{
			background-color: #000; 
			border: none;
			color : #ffffff;
			font-weight: bold;
			padding: 7px 25px;
		}	
		.snatika{
			color : #990099;
		}
		.custom-btnexit{
			background-color: #000; 
			border: none;
			color : #ffffff;
			font-weight: bold;
			padding: 7px 25px;
		}
		.custom-btnexit:hover{
			background-color: #990099; 
			border: none;
			color : #ffffff;
			font-weight: bold;
			padding: 7px 25px;
		}	
	</style>
</head>
<body>
	<div class="container">
		<div class="section">
			<div class="row">
				<div class="col main-head">
					<h2>Program Eligibility Test </h2>
				</div>
			</div>

			<div class="row">
				<div class="col-1 col-md-1"></div>
				<div class="col-10 col-md-10 detail-sec">
					<h3> Congratulation You are eligible for the below program. </h4>
					<h5><span class="snatika">Program Name</span> </h3>
					 
					<div class="clearfix"></div>
					<div class="row btn-sec">
						<div class="col-4 col-md-4"><a href="#">Download Broucher</a></div>
						<div class="col-8 col-md-8"><a href="#">Connect with your SNATIKA  Masters Guide</a></div>
					</div>

					<div class="row btn-sec">
						<div class="col-12 col-md-12"><button type="button" class="custom-btn">Thanks</button></div> 
						<br>
						<br>
						<div class="col-12 col-md-12"><a type="button" class="custom-btn" href="{{route('gohome')}}" style="text-decoration: none;">Restart Test</a></div>
					</div>
				</div>
				<div class="col-1 col-md-1"></div>
			</div>
		</div>
	</div>
</body>
</html>